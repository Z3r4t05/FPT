create proc SP_4
as select * from NHANVIEN
where MA_NQL is null
