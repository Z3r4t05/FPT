select job_desc from jobs
where min_lvl > 100 and max_lvl < 200