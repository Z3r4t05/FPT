select title, stor_id from sales s right join titles t 
on s.title_id = t.title_id
