SELECT p1.title_count, p2.title_count, p3.title_count
FROM pubCounts p1,  pubCounts p2,  pubCounts p3
WHERE p1.pub_name = 'Algodata Infosystems'
AND p2.pub_Name = 'Binnet & Hardley'
AND p3.pub_name = 'New Moon Books'
